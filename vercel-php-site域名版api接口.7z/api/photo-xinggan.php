<?php
$img=file('url-pic-xinggan.txt');
$url=array_rand($img);
header("Location:".$img[$url]);
?>